import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cards-game',
  templateUrl: './cards-game.component.html',
  styleUrls: ['./cards-game.component.scss'],
})
export class CardsGameComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
